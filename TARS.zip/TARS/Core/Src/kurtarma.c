#include <Wire.h>
#include <BMP180.h>
#include <bno055.h>

// BMP180 sensörü
BMP180 bmp;

// BNO055 sensörü
bno055 bno;

// Pin numaraları
const int ARM_PIN = 5;   // Koruma paraşütü için
const int MAIN_PIN = 12;  // Ana paraşüt için


// Yükseklik eşikleri (metre)
const int ARM_ALTITUDE = 1000;  // Koruma paraşütü açma yüksekliği
const int MAIN_ALTITUDE = 500;  // Ana paraşütü açma yüksekliği

void setup() {
  Serial.begin(9600);

  // BMP180 sensörünü başlat
  if (!bmp.begin()) {
    Serial.println("Could not find a valid BMP180 sensor, check wiring!");
    while (1) {}
  }

  // BNO055 sensörünü başlat
  if (!bno.begin()) {
    Serial.println("Could not find a valid bno055 sensor, check wiring!");
    while (1) {}
  }

  // Pin ayarlamaları
  pinMode(ARM_PIN, OUTPUT);
  pinMode(MAIN_PIN, OUTPUT);

  // Koruma paraşütü ve ana paraşütü kapalı konuma getir
  digitalWrite(ARM_PIN, LOW);
  digitalWrite(MAIN_PIN, LOW);

  Serial.println("Firlatmaya hazir!");
}

void loop() {
  // Yükseklik ölçümleri
  float altitude = bmp.readAltitude(1013.25);
  Serial.print("Altitude: ");
  Serial.print(altitude);
  Serial.print(" meters");

  // Roll, pitch ve yaw ölçümleri
  sensors_event_t event;
  bno.getEvent(&event);
  Serial.print("\tRoll: ");
  Serial.print(event.orientation.x);
  Serial.print(" degrees\tPitch: ");
  Serial.print(event.orientation.y);
  Serial.print(" degrees\tYaw: ");
  Serial.print(event.orientation.z);
  Serial.println(" degrees");

  // Koruma paraşütü kontrolü
  if (altitude <= ARM_ALTITUDE) {
    deploy_arm();
  }

  // Ana paraşüt kontrolü
  if (altitude <= MAIN_ALTITUDE) {
    deploy_main();
  }

  // Belirli bir süre beklet
  delay(1000);
}

// Ana paraşütü açma fonksiyonu
void deploy_main() {
  digitalWrite(MAIN_PIN, HIGH);
  Serial.println("Deploying main chute...");
}

// Koruma paraşütünü açma fonksiyonu
void deploy_arm() {
  digitalWrite(ARM_PIN, HIGH);
  Serial.println("Deploying arm chute...");
}
